<?php require_once ROOT . "app/views/" . $view . ".php"; ?>
